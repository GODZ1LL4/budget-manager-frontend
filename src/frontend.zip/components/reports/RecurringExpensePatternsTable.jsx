// src/components/reports/RecurringExpensePatternsTable.jsx
import { useEffect, useMemo, useState } from "react";
import axios from "axios";

const safeNum = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);

function formatCurrencyDOP(value) {
  const num = safeNum(value);
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    minimumFractionDigits: 2,
  }).format(num);
}

function formatDate(dateStr) {
  if (!dateStr) return "—";
  const [y, m, d] = String(dateStr).split("-");
  if (!y || !m || !d) return String(dateStr);
  return `${d}/${m}/${y}`;
}

const FREQUENCY_LABELS = {
  semanal: "Semanal",
  quincenal: "Quincenal",
  mensual: "Mensual",
  bimestral: "Bimestral",
  irregular: "Irregular",
};

function prettifyDescriptionKey(s) {
  if (!s) return "Sin descripción";
  const clean = String(s).trim();
  if (!clean) return "Sin descripción";
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

function RecurringExpensePatternsTable({ token }) {
  const api = import.meta.env.VITE_API_URL;

  const [data, setData] = useState([]);
  const [months, setMonths] = useState(6);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // ✅ Tokenized UI (sin Tailwind hardcoded de color)
  const ui = useMemo(() => {
    const border = "var(--border-rgba)";
    const panel = "var(--panel)";
    const panel2 = "var(--panel-2)";
    const bg2 = "var(--bg-2)";
    const bg3 = "var(--bg-3)";

    const cardBg = `linear-gradient(135deg, ${bg3}, color-mix(in srgb, ${panel} 78%, transparent), ${bg2})`;
    const headerBg = `color-mix(in srgb, ${panel2} 75%, ${bg3})`;
    const surface = `color-mix(in srgb, ${panel} 65%, transparent)`;
    const surfaceAlt = `color-mix(in srgb, ${panel2} 55%, transparent)`;

    return {
      border,
      text: "var(--text)",
      muted: "var(--muted)",
      primary: "var(--primary)",
      success: "var(--success)",
      danger: "var(--danger)",
      warning: "var(--warning)",
      ring: "var(--ring)",

      // Container
      card: {
        borderRadius: "var(--radius-lg)",
        border: `1px solid ${border}`,
        background: cardBg,
        boxShadow: "0 16px 40px rgba(0,0,0,0.85)",
      },

      // Controls
      select: {
        background: "var(--control-bg)",
        color: "var(--control-text)",
        border: `1px solid ${border}`,
        borderRadius: "var(--radius-md)",
      },

      // Table
      tableWrap: {
        borderRadius: "var(--radius-md)",
        border: `1px solid ${border}`,
        background: surface,
      },
      thead: {
        background: headerBg,
        borderBottom: `1px solid ${border}`,
      },
      rowEvenBg: "transparent",
      rowOddBg: surfaceAlt,
      rowHoverBg: "color-mix(in srgb, var(--panel-2) 65%, transparent)",

      // Pills
      pill: {
        background: "color-mix(in srgb, var(--panel-2) 70%, transparent)",
        border: `1px solid color-mix(in srgb, ${border} 85%, transparent)`,
        color: "var(--text)",
        borderRadius: 9999,
      },

      // Value accents
      avgAmount: "var(--success)",
      error: "var(--danger)",
    };
  }, []);

  useEffect(() => {
    if (!token) return;

    setLoading(true);
    setError("");

    axios
      .get(`${api}/analytics/recurring-expense-patterns`, {
        headers: { Authorization: `Bearer ${token}` },
        params: { months },
      })
      .then((res) => setData(res?.data?.data || []))
      .catch((err) => {
        console.error("Error cargando patrones recurrentes:", err);
        setError(
          err.response?.data?.error ||
            "No se pudieron cargar los patrones de gasto recurrente."
        );
        setData([]);
      })
      .finally(() => setLoading(false));
  }, [token, months, api]);

  return (
    <div className="rounded-2xl p-6 space-y-4" style={ui.card}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h3 className="text-xl font-semibold" style={{ color: ui.text }}>
            Patrones de gasto recurrente (no marcados)
          </h3>
          <p className="text-sm mt-1" style={{ color: ui.muted }}>
            Detecta gastos que se repiten con frecuencia similar (semanal,
            quincenal, mensual, etc.) aunque no estén configurados como
            transacciones recurrentes.
          </p>
        </div>

        {/* Filtro de meses */}
        <div className="flex items-center gap-2 text-sm">
          <span style={{ color: ui.muted }}>Últimos</span>

          <select
            value={months}
            onChange={(e) => setMonths(Number(e.target.value) || 6)}
            className="px-3 py-2 text-sm outline-none focus:outline-none"
            style={ui.select}
            onFocus={(e) => {
              e.currentTarget.style.boxShadow = "var(--glow-shadow)";
              e.currentTarget.style.borderColor =
                "color-mix(in srgb, var(--ring) 55%, var(--border-rgba))";
            }}
            onBlur={(e) => {
              e.currentTarget.style.boxShadow = "none";
              e.currentTarget.style.borderColor = "var(--border-rgba)";
            }}
          >
            <option value={3}>3 meses</option>
            <option value={6}>6 meses</option>
            <option value={12}>12 meses</option>
          </select>
        </div>
      </div>

      {/* Estados */}
      {loading ? (
        <p className="text-sm italic" style={{ color: ui.muted }}>
          Cargando patrones…
        </p>
      ) : error ? (
        <div
          className="rounded-xl px-4 py-3 text-sm"
          style={{
            border: `1px solid color-mix(in srgb, ${ui.error} 45%, ${ui.border})`,
            background:
              "color-mix(in srgb, var(--danger) 14%, transparent)",
            color: "color-mix(in srgb, var(--danger) 75%, var(--text))",
          }}
        >
          {error}
        </div>
      ) : data.length === 0 ? (
        <p className="text-sm italic" style={{ color: ui.muted }}>
          No se encontraron patrones de gasto recurrente en el período
          seleccionado.
        </p>
      ) : (
        <div className="overflow-x-auto" style={ui.tableWrap}>
          <table className="min-w-full text-sm" style={{ color: ui.text }}>
            <thead style={ui.thead}>
              <tr>
                <th
                  className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Categoría
                </th>
                <th
                  className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Descripción / Concepto
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Frecuencia
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Ocurrencias
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Intervalo mediano (días)
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Intervalo medio (días)
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Desv. estándar (días)
                </th>
                <th
                  className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Monto promedio
                </th>
                <th
                  className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide"
                  style={{ color: ui.muted }}
                >
                  Última vez
                </th>
              </tr>
            </thead>

            <tbody>
              {data.map((row, idx) => {
                const baseBg = idx % 2 === 0 ? ui.rowEvenBg : ui.rowOddBg;

                return (
                  <tr
                    key={`${row.category_id || "cat"}-${
                      row.description_key || "desc"
                    }-${idx}`}
                    style={{
                      background: baseBg,
                      borderTop: `1px solid color-mix(in srgb, ${ui.border} 60%, transparent)`,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = ui.rowHoverBg;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = baseBg;
                    }}
                  >
                    <td className="px-3 py-2 align-top">
                      <div className="flex flex-col">
                        <span className="font-semibold" style={{ color: ui.text }}>
                          {row.category_name || "Sin categoría"}
                        </span>
                      </div>
                    </td>

                    <td className="px-3 py-2 align-top" style={{ color: ui.text }}>
                      {prettifyDescriptionKey(row.description_key)}
                    </td>

                    <td className="px-3 py-2 align-top text-center">
                      <span
                        className="inline-flex items-center px-2 py-0.5 text-[11px] font-semibold"
                        style={ui.pill}
                      >
                        {FREQUENCY_LABELS[row.frequency_label] ||
                          row.frequency_label ||
                          "—"}
                      </span>
                    </td>

                    <td
                      className="px-3 py-2 align-top text-center"
                      style={{ color: ui.text }}
                    >
                      {safeNum(row.occurrences) || 0}
                    </td>

                    <td
                      className="px-3 py-2 align-top text-center"
                      style={{ color: ui.text }}
                    >
                      {safeNum(row.median_interval_days) || 0}
                    </td>

                    <td
                      className="px-3 py-2 align-top text-center"
                      style={{ color: ui.text }}
                    >
                      {safeNum(row.mean_interval_days) || 0}
                    </td>

                    <td
                      className="px-3 py-2 align-top text-center"
                      style={{ color: ui.text }}
                    >
                      {safeNum(row.std_dev_interval_days) || 0}
                    </td>

                    <td
                      className="px-3 py-2 align-top text-right font-semibold"
                      style={{ color: ui.avgAmount }}
                    >
                      {formatCurrencyDOP(row.avg_amount)}
                    </td>

                    <td
                      className="px-3 py-2 align-top text-center"
                      style={{ color: ui.muted }}
                    >
                      {formatDate(row.last_date)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default RecurringExpensePatternsTable;
