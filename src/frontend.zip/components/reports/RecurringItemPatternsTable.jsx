// src/components/reports/RecurringItemPatternsTable.jsx
import { useEffect, useState } from "react";
import axios from "axios";

function formatCurrencyDOP(value) {
  const num = Number(value) || 0;
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    minimumFractionDigits: 2,
  }).format(num);
}

function formatDate(dateStr) {
  if (!dateStr) return "—";
  const [y, m, d] = String(dateStr).split("-");
  if (!y || !m || !d) return dateStr;
  return `${d}/${m}/${y}`;
}

const FREQUENCY_LABELS = {
  semanal: "Semanal",
  quincenal: "Quincenal",
  mensual: "Mensual",
  bimestral: "Bimestral",
  irregular: "Irregular",
};

function prettifyKey(s) {
  if (!s) return "—";
  const clean = String(s).trim();
  if (!clean) return "—";
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

function RecurringItemPatternsTable({ token }) {
  const [data, setData] = useState([]);
  const [months, setMonths] = useState(6);
  const [minOccurrences, setMinOccurrences] = useState(3);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const api = import.meta.env.VITE_API_URL;

  useEffect(() => {
    if (!token) return;

    setLoading(true);
    setError("");

    axios
      .get(`${api}/analytics/recurring-item-patterns`, {
        headers: { Authorization: `Bearer ${token}` },
        params: { months, min_occurrences: minOccurrences },
      })
      .then((res) => setData(res.data?.data || []))
      .catch((err) => {
        console.error("Error cargando patrones recurrentes por ítem:", err);
        setError(
          err.response?.data?.error ||
            "No se pudieron cargar los patrones de compra por artículo."
        );
      })
      .finally(() => setLoading(false));
  }, [token, months, minOccurrences, api]);

  // Scroll vertical desde 15 filas (aprox. 15 filas + header)
  const enableYScroll = data.length >= 15;
  const HEADER_H = 44;
  const ROW_H = 44;
  const maxTableHeightPx = HEADER_H + ROW_H * 15;

  // Clases tokenizadas
  const cardClass =
    "rounded-2xl p-6 space-y-4 border border-[var(--border-rgba)] " +
    "bg-gradient-to-br " +
    "from-[color-mix(in_srgb,var(--bg-1)_100%,transparent)] " +
    "via-[color-mix(in_srgb,var(--bg-2)_100%,transparent)] " +
    "to-[color-mix(in_srgb,var(--bg-1)_100%,transparent)] " +
    "shadow-[0_16px_40px_color-mix(in_srgb,#000_85%,transparent)]";

  const titleClass = "text-xl font-semibold text-[var(--text)]";
  const subtitleClass = "text-sm text-[var(--muted)] mt-1";

  const filterLabelClass = "text-[var(--muted)]";
  const selectClass =
    "bg-[var(--panel-2)] border border-[var(--border-rgba)] rounded-lg " +
    "px-2 py-1 text-sm text-[var(--text)] " +
    "focus:outline-none focus:ring-2 focus:ring-[var(--ring)]";

  const hintClass = "text-sm text-[var(--muted)] italic";
  const emptyClass =
    "text-sm text-[color-mix(in_srgb,var(--muted)_80%,transparent)] italic";
  const errorClass =
    "text-sm text-[color-mix(in_srgb,var(--danger)_75%,var(--text))]";

  const tableOuterClass =
    "relative rounded-xl border border-[var(--border-rgba)] " +
    "bg-[color-mix(in_srgb,var(--panel)_70%,transparent)] " +
    "overflow-x-auto";

  const tableClass =
    "min-w-full w-full table-fixed border-separate border-spacing-0 " +
    "text-[12px] text-[var(--text)]";

  const thStickyBase =
    "sticky top-0 z-30 px-1.5 py-1.5 " +
    "text-[10px] font-semibold uppercase tracking-wide " +
    "text-[var(--muted)] " +
    "bg-[color-mix(in_srgb,var(--panel-2)_88%,transparent)] " +
    "backdrop-blur-md " +
    "border-b border-[var(--border-rgba)] " +
    "shadow-[0_10px_18px_color-mix(in_srgb,#000_35%,transparent)]";

  const tdBase = "px-1.5 py-1.5 align-top";

  const zebraA =
    "bg-[color-mix(in_srgb,var(--panel)_55%,transparent)] border-t border-[color-mix(in_srgb,var(--border-rgba)_65%,transparent)]";
  const zebraB =
    "bg-[color-mix(in_srgb,var(--panel-2)_60%,transparent)] border-t border-[color-mix(in_srgb,var(--border-rgba)_65%,transparent)]";

  const tdMuted = "text-[color-mix(in_srgb,var(--muted)_85%,var(--text))]";
  const tdSoft = "text-[color-mix(in_srgb,var(--text)_85%,transparent)]";

  const pillClass =
    "inline-flex items-center px-1.5 py-0.5 rounded-full " +
    "bg-[color-mix(in_srgb,var(--panel-2)_80%,transparent)] " +
    "text-[10px] text-[var(--text)] " +
    "border border-[color-mix(in_srgb,var(--border-rgba)_85%,transparent)] " +
    "whitespace-nowrap";

  const amountClass =
    "text-right font-semibold tabular-nums whitespace-nowrap " +
    "text-[color-mix(in_srgb,var(--primary)_65%,var(--text))]";

  const lastAmountClass =
    "text-[10px] whitespace-nowrap " +
    "text-[color-mix(in_srgb,var(--muted)_90%,transparent)]";

  return (
    <div className={cardClass}>
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-3">
        <div>
          <h3 className={titleClass}>Patrones de compra por artículo</h3>
          <p className={subtitleClass}>
            Detecta artículos que compras con una frecuencia similar (semanal,
            mensual, etc.), aunque no estén configurados como transacciones
            recurrentes.
          </p>
        </div>

        {/* Filtros */}
        <div className="flex flex-wrap gap-3 text-sm items-center">
          <div className="flex items-center gap-2">
            <span className={filterLabelClass}>Período:</span>
            <select
              value={months}
              onChange={(e) => setMonths(Number(e.target.value) || 6)}
              className={selectClass}
            >
              <option value={3}>Últimos 3 meses</option>
              <option value={6}>Últimos 6 meses</option>
              <option value={12}>Últimos 12 meses</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className={filterLabelClass}>Mín. ocurrencias:</span>
            <select
              value={minOccurrences}
              onChange={(e) => setMinOccurrences(Number(e.target.value) || 3)}
              className={selectClass}
            >
              <option value={2}>2+</option>
              <option value={3}>3+</option>
              <option value={4}>4+</option>
              <option value={5}>5+</option>
            </select>
          </div>
        </div>
      </div>

      {/* Estados */}
      {loading && (
        <p className={hintClass}>Buscando patrones de compra por artículo…</p>
      )}
      {error && <p className={errorClass}>{error}</p>}
      {!loading && !error && data.length === 0 && (
        <p className={emptyClass}>
          No se encontraron patrones de compra para el período y filtros
          seleccionados.
        </p>
      )}

      {/* Tabla */}
      {!loading && !error && data.length > 0 && (
        <div
          className={`${tableOuterClass} ${enableYScroll ? "overflow-y-auto" : ""}`}
          style={enableYScroll ? { maxHeight: `${maxTableHeightPx}px` } : undefined}
        >
          <table className={tableClass}>
            <thead className="relative z-20">
              <tr>
                <th className={`${thStickyBase} w-[160px] text-left`}>
                  Artículo
                </th>
                <th className={`${thStickyBase} w-[90px] text-left`}>
                  Categoría
                </th>
                <th className={`${thStickyBase} w-[120px] text-left`}>
                  Variante
                  <span className="block">/ Concepto</span>
                </th>
                <th className={`${thStickyBase} w-[80px] text-center`}>Frec.</th>
                <th className={`${thStickyBase} w-[70px] text-center`}>Ocurr.</th>
                <th className={`${thStickyBase} w-[75px] text-center`}>
                  Med.<span className="block">(d)</span>
                </th>
                <th className={`${thStickyBase} w-[75px] text-center`}>
                  Media<span className="block">(d)</span>
                </th>
                <th className={`${thStickyBase} w-[75px] text-center`}>
                  Desv.<span className="block">(d)</span>
                </th>
                <th className={`${thStickyBase} w-[75px] text-center`}>
                  Cant.<span className="block">prom.</span>
                </th>
                <th className={`${thStickyBase} w-[95px] text-right`}>
                  Monto<span className="block">prom.</span>
                </th>
                <th className={`${thStickyBase} w-[90px] text-center`}>
                  Última<span className="block">compra</span>
                </th>
              </tr>
            </thead>

            <tbody>
              {data.map((row, idx) => (
                <tr
                  key={`${row.item_id || "item"}-${row.description_key || "desc"}-${idx}`}
                  className={idx % 2 === 0 ? zebraA : zebraB}
                >
                  {/* Artículo */}
                  <td className={tdBase}>
                    <div className="w-[160px] break-words leading-snug font-semibold">
                      {row.item_name || "Sin nombre"}
                    </div>
                  </td>

                  {/* Categoría (truncate) */}
                  <td className={`${tdBase} ${tdMuted}`}>
                    <div className="w-[90px] truncate" title={row.category_name || ""}>
                      {row.category_name || "—"}
                    </div>
                  </td>

                  {/* Variante / Concepto (truncate) */}
                  <td className={`${tdBase} ${tdSoft}`}>
                    <div
                      className="w-[120px] truncate"
                      title={prettifyKey(row.description_key)}
                    >
                      {prettifyKey(row.description_key)}
                    </div>
                  </td>

                  {/* Frecuencia */}
                  <td className={`${tdBase} text-center`}>
                    <span className={pillClass}>
                      {FREQUENCY_LABELS[row.frequency_label] ||
                        row.frequency_label ||
                        "—"}
                    </span>
                  </td>

                  <td className={`${tdBase} text-center tabular-nums`}>
                    {row.occurrences}
                  </td>
                  <td className={`${tdBase} text-center tabular-nums`}>
                    {row.median_interval_days}
                  </td>
                  <td className={`${tdBase} text-center tabular-nums`}>
                    {row.mean_interval_days}
                  </td>
                  <td className={`${tdBase} text-center tabular-nums`}>
                    {row.std_dev_interval_days}
                  </td>
                  <td className={`${tdBase} text-center tabular-nums`}>
                    {Number(row.avg_quantity || 0).toFixed(2)}
                  </td>

                  <td className={`${tdBase} ${amountClass}`}>
                    {formatCurrencyDOP(row.avg_amount)}
                  </td>

                  <td className={`${tdBase} text-center ${tdMuted} tabular-nums`}>
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="whitespace-nowrap">
                        {formatDate(row.last_date)}
                      </span>
                      {row.last_amount != null && (
                        <span className={lastAmountClass}>
                          {formatCurrencyDOP(row.last_amount)}
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default RecurringItemPatternsTable;
