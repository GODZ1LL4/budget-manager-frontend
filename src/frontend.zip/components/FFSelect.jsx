//frontend\src\components\FFSelect.jsx

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

function normalize(s) {
  return String(s || "").toLowerCase().trim();
}

function PortalDropdown({ anchorEl, open, onClose, children }) {
  const [style, setStyle] = useState(null);

  useEffect(() => {
    if (!open) return;

    const update = () => {
      if (!anchorEl) return;
      const rect = anchorEl.getBoundingClientRect();
    
      const gap = 6;
      const padding = 12;
      const desired = 320;
      const minH = 160;
    
      const spaceBelow = window.innerHeight - rect.bottom - gap - padding;
      const spaceAbove = rect.top - gap - padding;
    
      const shouldOpenUp = spaceBelow < 220 && spaceAbove > spaceBelow;
    
      const maxH = Math.max(
        minH,
        Math.min(desired, shouldOpenUp ? spaceAbove : spaceBelow)
      );
    
      const base = {
        position: "fixed",
        left: rect.left,
        width: rect.width,
        maxHeight: maxH,
        zIndex: 9999,
      };
    
      // ✅ clave: si abre arriba, ancla con bottom al borde superior del input
      setStyle(
        shouldOpenUp
          ? { ...base, bottom: window.innerHeight - rect.top + gap }
          : { ...base, top: rect.bottom + gap }
      );
    };
    

    update();
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);

    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [open, anchorEl]);

  if (!open || !style) return null;

  return createPortal(
    <>
      <button
        type="button"
        onClick={onClose}
        className="fixed inset-0 z-[9998] cursor-default"
        aria-label="close"
        tabIndex={-1}
      />

      <div
        style={{
          ...style,
          background: "var(--select-bg)",
          borderColor: "var(--border-rgba)",
          boxShadow: "var(--select-shadow)",
        }}
        className="z-[9999] overflow-y-auto overscroll-contain border"
      >
        {children}
      </div>
    </>,
    document.body
  );
}

export default function FFSelect({
  value,
  onChange,
  options = [],
  placeholder = "Selecciona...",
  disabled = false,

  searchable = true,
  clearable = true,
  maxVisible = 80,

  getOptionLabel,
  getOptionValue,
  renderOption,
  className = "",
}) {
  const inputRef = useRef(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const getVal = (opt) =>
    getOptionValue ? getOptionValue(opt) : opt?.value ?? opt?.id ?? opt;
  const getLab = (opt) =>
    getOptionLabel ? getOptionLabel(opt) : opt?.label ?? opt?.name ?? String(opt);

  const selectedOption = useMemo(() => {
    const v = value ?? "";
    return options.find((o) => String(getVal(o)) === String(v)) || null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [options, value]);

  useEffect(() => {
    if (!open) {
      setQuery(selectedOption ? getLab(selectedOption) : "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, selectedOption]);

  useEffect(() => {
    setQuery(selectedOption ? getLab(selectedOption) : "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = normalize(query);
    if (!searchable || !q) return options;
    return options.filter((o) => normalize(getLab(o)).includes(q));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [options, query, searchable]);

  const visibleOptions = useMemo(
    () => filtered.slice(0, maxVisible),
    [filtered, maxVisible]
  );

  const close = () => setOpen(false);

  const openNow = () => {
    if (disabled) return;
    setOpen(true);
  
    // ✅ Al abrir: vacía el query para NO filtrar y mostrar todo
    if (searchable) setQuery("");
  
    queueMicrotask(() => {
      const el = inputRef.current;
      if (!el) return;
      if (typeof el.focus === "function") el.focus();
      if (typeof el.select === "function") el.select();
    });
  };
  

  const commit = (opt) => {
    const v = getVal(opt);
    onChange?.(v, opt);
    setOpen(false);
  };

  const clear = () => {
    onChange?.("", null);
    setQuery("");
    setOpen(false);
  };

  return (
    <div className={className}>
      <div className="relative">
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            const v = e.target.value;
            setQuery(v);
            if (!open) setOpen(true);

            if (clearable && v.trim() === "") {
              onChange?.("", null);
            }
          }}
          onFocus={() => openNow()}
          onClick={() => openNow()}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={!searchable}
          className="ff-input pr-10"
          style={{
            cursor: disabled ? "not-allowed" : searchable ? "text" : "pointer",
            borderWidth: "var(--select-border-w)",
            borderRadius: "var(--select-radius)",
          }}
        />

        <button
          type="button"
          onClick={() => (open ? close() : openNow())}
          disabled={disabled}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md px-2 py-1 text-xs"
          style={{ color: "var(--select-muted)", background: "transparent" }}
          aria-label="toggle"
        >
          ▾
        </button>
      </div>

      <PortalDropdown
        anchorEl={inputRef.current}
        open={open && !disabled}
        onClose={close}
      >
        {clearable && (
          <button
            type="button"
            onClick={clear}
            className="w-full text-left px-3 py-2 text-xs border-b"
            style={{
              color: "var(--select-muted)",
              borderColor:
                "color-mix(in srgb, var(--border-rgba) 70%, transparent)",
              background:
                "color-mix(in srgb, var(--panel) 40%, transparent)",
            }}
          >
            — Limpiar selección —
          </button>
        )}

        {visibleOptions.map((opt) => {
          const v = getVal(opt);
          const label = getLab(opt);
          const isActive = String(v) === String(value ?? "");

          return (
            <button
              key={String(v)}
              type="button"
              onClick={() => commit(opt)}
              className="w-full text-left px-3 py-2 text-sm"
              style={{
                color: "var(--select-text)",
                borderRadius: "var(--select-item-radius)",
                background: isActive ? "var(--select-active-bg)" : "transparent",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "var(--select-hover-bg)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = isActive
                  ? "var(--select-active-bg)"
                  : "transparent";
              }}
            >
              {renderOption ? renderOption(opt, { isActive }) : label}
            </button>
          );
        })}

        {filtered.length === 0 && (
          <div className="px-3 py-2 text-xs" style={{ color: "var(--select-muted)" }}>
            No hay resultados.
          </div>
        )}

        {filtered.length > maxVisible && (
          <div className="px-3 py-2 text-[11px]" style={{ color: "var(--select-muted)" }}>
            Mostrando {maxVisible} de {filtered.length}. Refina tu búsqueda.
          </div>
        )}
      </PortalDropdown>
    </div>
  );
}
